var searchData=
[
  ['reserve_0',['reserve',['../classcs1c_1_1vector.html#a47f233c2b59bc5f47230ed11392a8d40',1,'cs1c::vector']]],
  ['resize_1',['resize',['../classcs1c_1_1vector.html#a2e694ab1a1bfa28f10ea83e8e749c7b0',1,'cs1c::vector']]]
];
