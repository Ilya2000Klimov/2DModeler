var searchData=
[
  ['text_0',['Text',['../namespacecs1c.html#a92b6bdc8e0d07b381391a07ca3e4fdc4abbb2a33e68c5c3ab77a5524a4d1325bd',1,'cs1c']]]
];
