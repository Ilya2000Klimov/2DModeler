var searchData=
[
  ['ellipse_0',['Ellipse',['../classcs1c_1_1_ellipse.html',1,'cs1c::Ellipse'],['../classcs1c_1_1_ellipse.html#aaff4917eddd8882616fe2f956151ba9b',1,'cs1c::Ellipse::Ellipse()'],['../classcs1c_1_1_ellipse.html#a4b7309e616b7e6f12429df1a67a81108',1,'cs1c::Ellipse::Ellipse(QPainter *pPainter)'],['../classcs1c_1_1_ellipse.html#af641d4017b6844bdc1a63d7fecc066f6',1,'cs1c::Ellipse::Ellipse(QPainter *pPainter, int x, int y, int width, int height)']]]
];
