var searchData=
[
  ['text_0',['Text',['../classcs1c_1_1_text.html',1,'cs1c']]]
];
