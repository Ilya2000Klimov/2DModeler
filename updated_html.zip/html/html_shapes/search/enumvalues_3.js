var searchData=
[
  ['polygon_0',['Polygon',['../namespacecs1c.html#a92b6bdc8e0d07b381391a07ca3e4fdc4acc86f08e2c2325e9fa0e7a6eae888953',1,'cs1c']]],
  ['polyline_1',['Polyline',['../namespacecs1c.html#a92b6bdc8e0d07b381391a07ca3e4fdc4ada6868d9c5d06bdd1d61a6fe9fddf47c',1,'cs1c']]]
];
