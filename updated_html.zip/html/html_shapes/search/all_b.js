var searchData=
[
  ['text_0',['Text',['../classcs1c_1_1_text.html',1,'cs1c::Text'],['../classcs1c_1_1_text.html#ab3e26143fccc52699bcc5149cae852bc',1,'cs1c::Text::Text()'],['../classcs1c_1_1_text.html#a2f67e1bc3b7dfcebaab597a31d30eb3e',1,'cs1c::Text::Text(QPainter *pPainter)']]]
];
